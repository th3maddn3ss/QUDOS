
import json, csv
from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"; REPORTS.mkdir(parents=True, exist_ok=True)

spec = importlib.util.spec_from_file_location("asm", str(ROOT/"code"/"quit_risc_asm_yaml.py"))
asm = importlib.util.module_from_spec(spec); spec.loader.exec_module(asm)
spec2 = importlib.util.spec_from_file_location("ws", str(ROOT/"code"/"waveform_synth.py"))
ws = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(ws)

def run():
    placement_path = str(ROOT/"placement"/"placement_example.yaml")
    placement = asm.load_placement(placement_path)
    program = [
        "QCPZ 0, 1, 1, 2, 0.7rad",
        "QCRT 0, 1, 1, 2, 3, 0.4rad",
        "QPHZ 1, 2, 15deg",
        "QROT 1, 1, 2, 10deg"
    ]
    words, ops = asm.assemble_lines(program, placement)

    (REPORTS/"assembled_words.json").write_text(json.dumps({"words_dec":words,"words_hex":[hex(w) for w in words]}, indent=2))

    # Listing CSV
    with (REPORTS/"program_listing.csv").open("w", newline="") as f:
        import csv
        w = csv.DictWriter(f, fieldnames=["idx","word_hex","kind","rt","rc","i","j","k","t_level","theta_rad"])
        w.writeheader()
        for idx,(w32,op) in enumerate(zip(words,ops)):
            w.writerow({"idx":idx,"word_hex":hex(w32),"kind":op.get("kind"),"rt":op.get("rt"),
                        "rc":op.get("rc"),"i":op.get("i"),"j":op.get("j"),"k":op.get("k"),
                        "t_level":op.get("t_level"),"theta_rad":op.get("theta")})

    schedule = ws.synth_qrotz_schedule(ops, placement)
    import pandas as pd
    df = pd.DataFrame(schedule)
    df.to_csv(REPORTS/"waveform_schedule_device.csv", index=False)
    (REPORTS/"waveform_schedule_device.json").write_text(json.dumps(schedule, indent=2))

    return (REPORTS/"assembled_words.json", REPORTS/"program_listing.csv",
            REPORTS/"waveform_schedule_device.csv", REPORTS/"waveform_schedule_device.json")

if __name__ == "__main__":
    print("\\n".join(str(p) for p in run()))
