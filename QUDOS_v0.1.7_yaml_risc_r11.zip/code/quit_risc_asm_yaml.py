
from __future__ import annotations
import re, json, math
from typing import List, Dict, Any, Tuple

try:
    import yaml  # type: ignore
except Exception:
    yaml = None

def load_placement(path: str) -> Dict[str, Any]:
    if path.endswith(".json"):
        return json.load(open(path,"r"))
    if yaml is None:
        return json.load(open(path.replace(".yaml",".json"),"r"))
    return yaml.safe_load(open(path,"r"))

def parse_angle(val: str) -> float:
    s = val.strip().lower()
    if s.endswith("rad"): return float(s[:-3])
    if s.endswith("deg"): return math.radians(float(s[:-3]))
    return math.radians(float(s))

def assemble_lines(lines: List[str], placement: Dict[str, Any]):
    enc = placement["risc_encoding"]; opc = enc["opcodes"]
    scale = enc["theta_fixed_scale"]; words=[]; ops=[]
    def pack(op, rt, rc, i, j, k, th):
        tf = int(round(th*scale)) & 0xFF
        return ((op & 0xF)<<28)|((rt & 0xF)<<24)|((rc & 0xF)<<20)|((i & 0xF)<<16)|((j & 0xF)<<12)|((k & 0xF)<<8)|tf
    for ln in lines:
        ln=ln.strip()
        if not ln or ln.startswith("#"): continue
        toks = ln.replace(',', ' ').split(); m=toks[0].upper()
        if m=="QPHZ":
            _,rt,k,th=toks; rt=int(rt); k=int(k); th=parse_angle(th)
            words.append(pack(opc["QPHZ"],rt,0,0,0,k,th)); ops.append({"kind":"QPHZ","rt":rt,"k":k,"theta":th})
        elif m=="QROT":
            _,rt,i,j,th=toks; rt=int(rt); i=int(i); j=int(j); th=parse_angle(th)
            words.append(pack(opc["QROT"],rt,0,i,j,0,th)); ops.append({"kind":"QROT","rt":rt,"i":i,"j":j,"theta":th})
        elif m=="QCPZ":
            _,rc,k,rt,tlev,th=toks; rc=int(rc); k=int(k); rt=int(rt); tlev=int(tlev); th=parse_angle(th)
            words.append(pack(opc["QCPZ"],rt,rc,0,0,k,th)); ops.append({"kind":"QCPZ","rc":rc,"rt":rt,"k":k,"t_level":tlev,"theta":th})
        elif m=="QCRT":
            _,rc,k,rt,i,j,th=toks; rc=int(rc); k=int(k); rt=int(rt); i=int(i); j=int(j); th=parse_angle(th)
            words.append(pack(opc["QCRT"],rt,rc,i,j,k,th)); ops.append({"kind":"QCRT","rc":rc,"rt":rt,"k":k,"i":i,"j":j,"theta":th})
        else:
            raise ValueError("Unknown mnemonic: "+m)
    return words, ops
