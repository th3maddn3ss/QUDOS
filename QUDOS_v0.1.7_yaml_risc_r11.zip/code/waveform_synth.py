
from __future__ import annotations
from typing import List, Dict, Any

def synth_qrotz_schedule(program_ops: List[Dict[str, Any]], placement: Dict[str, Any]) -> List[Dict[str, Any]]:
    dt_ns = placement["timing"]["dt_ns"]
    wz = placement["waveforms"]["gaussian"]
    rot_scale = placement["calibration"]["rot_scale_per_rad"]
    reg_map = {r["reg"]: r for r in placement["mapping"]["registers"]}
    t = 0.0; sched = []
    for op in program_ops:
        kind = op["kind"]; rt = op["rt"]
        if kind in ("QROT","QCRT"):
            ch = reg_map[rt]["drive_channel"]
            dur = wz["length_ns"]; amp = rot_scale * abs(op["theta"])
            freq = reg_map[rt]["levels"][op.get("i", 0)]["freq_hz"]
            sched.append({"t0_ns":t,"t1_ns":t+dur,"chan":ch,"shape":"gaussian",
                          "sigma_ns":wz["sigma_ns"],"amp":amp,"freq_hz":freq})
            t += dur
        elif kind in ("QPHZ","QCPZ"):
            sched.append({"t0_ns":t,"t1_ns":t,"chan":reg_map[rt]["drive_channel"],
                          "shape":"frame_update","phase_rad":op["theta"]})
        else:
            raise ValueError("Unknown op kind: "+str(kind))
        t += dt_ns
    return sched
